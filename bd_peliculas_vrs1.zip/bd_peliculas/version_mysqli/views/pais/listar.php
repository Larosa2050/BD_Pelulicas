<?php 
  
// Título de la página 
$tituloPagina = "Listado de países"; 
  
// Incluir encabezado 
require __DIR__ . "/../layouts/header.php"; 
  
?> 
  
<!-- Encabezado del módulo --> 
<div class="d-flex flex-wrap justify-content-between 
            align-items-center mb-4"> 
  
    <div> 
        <h1 class="h3 mb-1"> 
            Gestión de países 
        </h1> 
  
        <p class="text-muted mb-0"> 
            Listado de países registrados en el sistema. 
        </p> 
    </div> 
  
    <span class="badge text-bg-primary fs-6"> 
        Total: <?= count($paises); ?> 
    </span> 
  
</div> 
  
<!-- Tarjeta principal --> 
<div class="card shadow-sm border-0"> 
  
    <div class="card-header bg-white py-3"> 
        <h2 class="h5 mb-0">Países registrados</h2> 
    </div> 
  
    <div class="card-body"> 
  
        <?php if (count($paises) > 0): ?> 
  
            <div class="table-responsive"> 
  
                <table class="table table-striped 
                              table-hover align-middle"> 
  
                    <thead class="table-dark"> 
                        <tr> 
                            <th scope="col">N.°</th> 
                            <th scope="col">Código</th> 
                            <th scope="col">Nombre del país</th> 
                        </tr> 
                    </thead> 
  
                    <tbody> 
  
                        <?php $numero = 1; ?> 
  
                        <?php foreach ($paises as $pais): ?> 
                             <tr> 
                                <td><?= $numero++; ?></td> 
  
                                <td> 
                                    <?= htmlspecialchars( 
                                        (string) $pais["pai_codi"], 
                                        ENT_QUOTES, 
                                        "UTF-8" 
                                    ); ?> 
                                </td> 
  
                                <td> 
                                    <?= htmlspecialchars( 
                                        $pais["pai_nomb"], 
                                        ENT_QUOTES, 
                                        "UTF-8" 
                                    ); ?> 
                                </td> 
                            </tr> 
  
                        <?php endforeach; ?> 
  
                    </tbody> 
  
                </table> 
  
            </div> 
  
        <?php else: ?> 
  
            <div class="alert alert-info mb-0"> 
                No existen países registrados. 
            </div> 
  
        <?php endif; ?> 
  
    </div> 
</div> 
  
<?php 
  
// Incluir pie de página 
require __DIR__ . "/../layouts/footer.php"; 
  
?> 