<?php 
  
// Controlar errores de la aplicación 
try { 
  
    // 1. Cargar conexión 
    $conexion = require __DIR__ . "/../config/database.php"; 
  
    // 2. Obtener parámetros de navegación 
    $modulo = $_GET["modulo"] ?? "pais"; 
    $accion = $_GET["accion"] ?? "listar"; 
  
    // 3. Verificar el módulo solicitado 
    if ($modulo === "pais") { 
  
        // 4. Verificar la acción 
        if ($accion === "listar") { 
  
            // Cargar controlador 
            require_once __DIR__ . 
                "/../controllers/paisControllers.php"; 
  
            // Ejecutar controlador 
            listarPaisesController($conexion); 
  
        } else { 
  
            http_response_code(404); 
            exit("Acción no encontrada."); 
  
        } 
  
    } else { 
  
        http_response_code(404); 
        exit("Módulo no encontrado."); 
  
    } 
  
} catch (mysqli_sql_exception $e) { 
  
    // Registrar error interno 
    error_log( 
        "Error en el módulo de países: " . 
        $e->getMessage() 
    ); 
  
    // Respuesta general 
    http_response_code(500); 
  
    exit("Ocurrió un error al procesar la solicitud."); 
  
}
?> 