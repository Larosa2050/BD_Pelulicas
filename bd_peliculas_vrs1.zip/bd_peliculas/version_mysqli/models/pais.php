<?php 
  
/** 
 * MODELO: PAIS 
 * Tecnología: MySQLi orientado a objetos 
 * Arquitectura: MVC procedimental 
 */ 
  
/** 
 * Listar todos los países registrados. 
 * 
 * @param mysqli $conexion 
 * @return array 
 */ 
function listarPaises($conexion) 
{ 
    // Consulta SQL 
    $sql = "SELECT pai_codi, pai_nomb 
            FROM TB_PAIS 
            ORDER BY pai_codi ASC"; 
  
    // Preparar consulta 
    $stmt = $conexion->prepare($sql); 
  
    // Ejecutar consulta 
    $stmt->execute(); 
  
    // Obtener resultados 
    $resultado = $stmt->get_result(); 
  
    // Array que almacenará los países 
    $paises = []; 
  
    // Recuperar los registros 
    while ($fila = $resultado->fetch_assoc()) { 
        $paises[] = $fila; 
    } 
  
    // Cerrar sentencia 
    $stmt->close(); 
  
    // Retornar los registros 
    return $paises; 
}
 ?> 