<?php 
  
/** 
 * CONTROLADOR: PAIS 
 * Arquitectura: MVC procedimental 
 */ 
  
// Incluir el modelo 
require_once __DIR__ . "/../models/pais.php"; 
  
/** 
 * Mostrar el listado de países. 
 * 
 * @param mysqli $conexion 
 * @return void 
 */ 
function listarPaisesController($conexion) 
{ 
    // Solicitar los países al modelo 
    $paises = listarPaises($conexion); 
  
    // Enviar los resultados a la vista 
    require __DIR__ . "/../views/pais/listar.php"; 
}
 ?> 